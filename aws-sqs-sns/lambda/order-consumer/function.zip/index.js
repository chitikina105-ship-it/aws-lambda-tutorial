import {
  SNSClient,
  PublishCommand
} from "@aws-sdk/client-sns";

console.log("AWS_REGION:", process.env.AWS_REGION);
console.log("SNS_TOPIC_ARN:", process.env.SNS_TOPIC_ARN);

const sns = new SNSClient({
  region: process.env.AWS_REGION
});

// Simulate order processing for now.
// Later, we'll replace this with PostgreSQL operations.
async function processOrder(order) {
  console.log("Processing order:", order.orderId);

  // Simulate processing failure for testing
  if (order.status === "FAILED") {
    throw new Error("Simulated order processing failure");
  }

  console.log("Order processed successfully:", order.orderId);
}

export const handler = async (event) => {
  const batchItemFailures = [];

  for (const record of event.Records ?? []) {
    try {
      // SQS message body
      const order = JSON.parse(record.body);

      // Process the order
      await processOrder(order);

      // Publish notification only after successful processing
      await sns.send(
        new PublishCommand({
          TopicArn: process.env.SNS_TOPIC_ARN,
          Subject: `Order ${order.orderId} completed`,
          Message: JSON.stringify({
            event: "ORDER_COMPLETED",
            orderId: order.orderId,
            customerName: order.customerName,
            amount: order.amount,
            status: "COMPLETED"
          })
        })
      );

      console.log("SNS notification published:", order.orderId);

    } catch (error) {
      console.error("Failed to process message:", record.messageId, error);

      batchItemFailures.push({
        itemIdentifier: record.messageId
      });
    }
  }

  return {
    batchItemFailures
  };
};